"""An EPUB exporter plugin for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_epub
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
import webbrowser

import gettext
import locale
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_epub',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

import datetime
from shutil import rmtree
from string import Template
import tempfile
import uuid
from xml import sax
import zipfile

from xml import sax


class NovxToXhtml(sax.ContentHandler):

    def __init__(self):
        super().__init__()
        self.xhtmlLines = None
        self._indentParagraph = None
        self._list = None
        self._note = None
        self._comment = None
        self._quotations = None
        self._firstParagraphInChapter = None
        self._spanLevel = None

    def feed(
        self,
        xmlString,
        append,
        firstInChapter,
        isEpigraph,
    ):
        self._firstParagraphInChapter = firstInChapter
        self._indentParagraph = append and not isEpigraph
        self._isEpigraph = isEpigraph
        self._quotations = False
        self._list = False
        self._note = False
        self._spanLevel = 0
        self._comment = False
        self.xhtmlLines = []
        if xmlString:
            sax.parseString(f'<content>{xmlString}</content>', self)

    def characters(self, content):
        if self._comment:
            return

        if self._note:
            return

        content = sax.saxutils.escape(content)
        self.xhtmlLines.append(content)
        self._indentParagraph = not self._quotations

    def endElement(self, name):
        if name == 'p':
            if self._list:
                return

            if self._note:
                return

            if self._comment:
                return

            while self._spanLevel > 0:
                self._spanLevel -= 1
                self.xhtmlLines.append('</span>')
            self.xhtmlLines.append('&nbsp;</p>\n')
            self._quotations = False
            return

        if name in ('em', 'strong', 'span'):
            self.xhtmlLines.append(f'</{name}>')
            return

        if name == 'comment':
            self._comment = False
            return

        if name == 'note':
            self._note = False
            return

        if name in ('h5', 'h6', 'h7', 'h8', 'h9',):
            while self._spanLevel > 0:
                self._spanLevel -= 1
                self.xhtmlLines.append('</span>')
            self.xhtmlLines.append('</p>\n')
            self._indentParagraph = False
            return

        if name == 'li':
            self.xhtmlLines.append(f'</{name}>\n')
            return

        if name == 'ul':
            self._list = False
            self._indentParagraph = False
            self.xhtmlLines.append('</ul>\n')
            return

    def startElement(self, name, attrs):
        xmlAttributes = {}
        for attribute in attrs.items():
            attrKey, attrValue = attribute
            xmlAttributes[attrKey] = attrValue

        if name == 'p':
            if self._list:
                return

            if self._note:
                return

            if self._comment:
                return

            if self._isEpigraph:
                self.xhtmlLines.append(f'<p class="epigraph">')
            elif xmlAttributes.get('style', None) == 'quotations':
                self.xhtmlLines.append('<p class="quotations">')
                self._quotations = True
                self._indentParagraph = False
            elif self._firstParagraphInChapter:
                self.xhtmlLines.append(f'<p class="chapter_beginning">')
            elif self._indentParagraph:
                self.xhtmlLines.append('<p class="first_line_indent">')
            else:
                self.xhtmlLines.append('<p class="text_body">')
            if not self._isEpigraph:
                self._firstParagraphInChapter = False
                self._indentParagraph = False

            language = xmlAttributes.get('xml:lang', None)
            if language:
                self.xhtmlLines.append(f'<span xml:lang="{language}">')
                self._spanLevel += 1
            return

        if name in ('em', 'strong', 'li'):
            self.xhtmlLines.append(f'<{name}>')
            return

        if name == 'span':
            language = xmlAttributes.get('xml:lang', None)
            if language:
                self.xhtmlLines.append(f'<span xml:lang="{language}">')
            return

        if name == 'comment':
            self._comment = True
            return

        if name == 'note':
            self._note = True
            return

        if name in ('h5', 'h6', 'h7', 'h8', 'h9',):
            level = name[-1]
            self.xhtmlLines.append(
                f'<p class="custom_{level}">'
            )
            language = xmlAttributes.get('xml:lang', None)
            if language:
                self.xhtmlLines.append(f'<span xml:lang="{language}">')
                self._spanLevel += 1
            return

        if name == 'ul':
            self._list = True
            self.xhtmlLines.append('<ul>\n')
            return


EPUB_SUFFIX = '_ebook'


class Stylesheet:

    DEFAULT_CSS = '''@namespace h "http://www.w3.org/1999/xhtml";
@page
    {
    margin: 5pt;
    }
body
    {
    font-family: "100 %", serif, sansserif;
    }
p
    {
    margin:0pt;
    text-indent:0em;
    line-height: 1.2em;
    text-align: left;
    font-size: 1.0em;
    widows: 2;
    orphans: 2;
    }
p.chapter_beginning, p.text_body
    {
    text-indent:0em;
    }
p.first_line_indent
    {
    text-indent:1.5em;
    }
p.quotations
    {
    text-indent:0em;
    margin-left:2.5em;
    margin-right: 1em;
    }
p.epigraph
    {
    font-size: 0.8em;
    margin-left:3em;
    margin-right:3em;
    margin-top:2em;
    margin-bottom:1.5em;
    line-height: 1em;
    }
p.epigraph_source
    {
    font-size: 0.8em;
    margin-left:3em;
    margin-right:3em;
    text-align: center;
    margin-bottom:3em;
    font-variant: small-caps;
    line-height: 1em;
    }
strong
    {
    font-weight: normal;
    text-transform: uppercase;
    }
em 
    {
    font-style: italic;
    }
h1
    {
    margin-top:4em;
    margin-bottom:2em;
    page-break-after:avoid;
    font-size: 1.20em;
    text-align: center;
    text-indent:0em;
    }
h2
    {
    margin-top:3em;
    margin-right:0em;
    margin-bottom:2em;
    margin-left:0em;
    page-break-after:avoid;
    font-size: 1.10em;
    text-align: center;
    text-indent:0em;
    }
h3
    {
    margin-top:2em;
    margin-bottom:2em;
    line-height:normal;
    page-break-after:avoid;
    font-size: 1.00em;
    text-align: center;
    text-indent:0em;
    }
h4
    {
    margin-top:2em;
    margin-bottom:2em;
    line-height:normal;
    page-break-after:avoid;
    font-size: .90em;
    text-align: center;
    text-indent:0em;
    }
p.custom_5
    {
    margin-top:2em;
    margin-bottom:2em;
    line-height:normal;
    page-break-after:avoid;
    font-size: .90em;
    text-align: center;
    text-indent:0em;
    }
p.custom_6, .custom_7, .custom_8, .custom_9
    {
    margin-top:2em;
    margin-bottom:2em;
    line-height:normal;
    page-break-after:avoid;
    font-size: .90em;
    text-align: center;
    text-indent:0em;
    }
.title
    {
    margin-top:2em;
    margin-bottom:1.5em;
    page-break-after:avoid;
    font-size: 1.50em;
    text-align: center;
    text-indent:0em;
    }
.subtitle, .author
    {
    margin-top:2em;
    margin-bottom:1.5em;
    page-break-after:avoid;
    font-size: 1.00em;
    text-align: center;
    text-indent:0em;
    }
'''

    def write_css(self, dirName, fileName):
        self.write_file(f'{dirName}/{fileName}', self.DEFAULT_CSS)
from abc import ABC
from urllib.parse import quote


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message



class File(ABC):
    DESCRIPTION = _('File')
    EXTENSION = None
    SUFFIX = None

    def __init__(self, filePath, **kwargs):
        self.novel = None
        self._filePath = None
        self.projectName = None
        self.projectPath = None
        self.sectionsSplit = False
        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath: str):
        filePath = filePath.replace('\\', '/')
        if self.SUFFIX is not None:
            suffix = self.SUFFIX
        else:
            suffix = ''
        if filePath.lower().endswith(f'{suffix}{self.EXTENSION}'.lower()):
            self._filePath = filePath
            try:
                head, tail = os.path.split(os.path.realpath(filePath))
            except:
                head, tail = os.path.split(filePath)
            self.projectPath = quote(head.replace('\\', '/'), '/:')
            self.projectName = quote(
                tail.replace(f'{suffix}{self.EXTENSION}', '')
            )

    def is_locked(self):
        return False

    def read(self):
        raise NotImplementedError

    def write(self):
        raise NotImplementedError



ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
FULL_MANUSCRIPT_SUFFIX = '_full_tmp'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
METADATA_TEXT_SUFFIX = '_metadata_text_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr



class Epub(File, Stylesheet):

    DESCRIPTION = 'EPUB e-book'
    EXTENSION = '.epub'
    SUFFIX = EPUB_SUFFIX
    CSS_NAME = 'nv_epub.css'

    _MIMETYPE = 'application/epub+zip'
    _CONTAINER_XML = (
        '<?xml version="1.0"?>\n'
        '<container version="1.0" '
        'xmlns="urn:oasis:names:tc:opendocument:xmlns:container">\n'
        '    <rootfiles>\n'
        '        <rootfile full-path='
        '"OEBPS/content.opf" media-type="application/oebps-package+xml"/>\n'
        '   </rootfiles>\n'
        '</container>\n'
    )
    _CONTENT_OPF_HEADER = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<package xmlns="http://www.idpf.org/2007/opf" '
        'unique-identifier="BookID" version="2.0">\n'
        '    <metadata xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:opf="http://www.idpf.org/2007/opf">\n'
        '        <dc:identifier id="BookID" '
        'opf:scheme="UUID">$Uuid</dc:identifier>\n'
        '        <dc:contributor opf:role="bkp">Created with nv_epub '
        '$Version by Peter Triesberger '
        'https://github.com/peter88213/nv_epub</dc:contributor>\n'
        '        <dc:date opf:event="creation">$Date</dc:date>\n'
        '        <dc:creator opf:role="aut">$Author</dc:creator>\n'
        '        <dc:language>$Language</dc:language>\n'
        '        <dc:title>$Title</dc:title>\n'
        '        <meta name="nv_epub" content="$Version"/>\n'
        '        <meta name="cover" content="cover.jpg"/>\n'
        '    </metadata>'
    )
    _CONTENT_OPF_FOOTER = (
        '    <guide>\n'
        '       <reference type="cover" '
        'title="Cover Page" href="$Coverpage"/>\n'
        '    </guide>\n'
        '</package>\n'
    )
    _TOC_NCX_HEADER = (
        '<?xml version="1.0"?>\n'
        '<!DOCTYPE ncx PUBLIC "-//NISO//DTD ncx 2005-1//EN"\n'
        '    "http://www.daisy.org/z3986/2005/ncx-2005-1.dtd">\n'
        '\n'
        '<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">\n'
        '    <head>\n'
        '        <meta name="dtb:uid" content="$Uuid"/>\n'
        '        <meta name="dtb:depth" content="2"/>\n'
        '        <meta name="dtb:totalPageCount" content="0"/>\n'
        '        <meta name="dtb:maxPageNumber" content="0"/>\n'
        '    </head>\n'
        '    <docTitle>\n'
        '        <text>$Title</text>\n'
        '    </docTitle>\n'
        '    <navMap>'
    )
    _TOC_NAV_POINT = (
'      <navPoint id="$NavpointID" playOrder="$Playorder">\n'
'        <navLabel>\n'
'          <text>$Title</text>\n'
'        </navLabel>\n'
'        <content src="text/$Filename#$HeadingID"/>\n'
'      </navPoint>'
    )
    _TOC_NCX_FOOTER = (
        '    </navMap>\n'
        '</ncx>\n'
    )
    _fileHeader = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"\n'
        '    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">\n'
        '<html xmlns="http://www.w3.org/1999/xhtml">\n'
        '<head>\n'
        '<link rel="stylesheet" '
        'href="../styles/$Stylesheet" type="text/css" />\n'
        '<title>$Title</title>\n'
        '</head>\n'
        '<body>\n'
    )
    _fileFooter = (
        '</body>\n'
        '</html>\n'
    )
    _frontmatter = (
        '<p class="title">$Title</p>\n'
        '<p class="author">$Author</p>\n'
    )
    _partTemplate = (
        '<h1 id="$ID">$Title</h1>\n'
    )
    _chapterTemplate = (
        '<h2 id="$ID">$Title</h2>\n'
    )
    _epigraphTemplate = '$SectionContent$Desc\n'
    _sectionTemplate = '$SectionContent\n'
    _sectionDivider = '<h4>* * *</h4>\n'

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self.version = kwargs['version']
        self.uuid = None
        self._tempDir = tempfile.mkdtemp(suffix='.tmp', prefix='nv_epub_')
        self._epubComponents = []
        self._ChIdsByContentFileNames = []
        self._contentParser = NovxToXhtml()

    def write(self):
        self._set_up()
        self.write_file('mimetype', self._MIMETYPE)
        self.uuid = str(uuid.uuid4())
        ChIdsByContentFileNames = self._write_chapters()
        self.write_css('OEBPS/styles', self.CSS_NAME)
        self._write_toc_ncx(ChIdsByContentFileNames)
        self._write_content_opf(ChIdsByContentFileNames)
        self.write_file('META-INF/container.xml', self._CONTAINER_XML)

        workdir = os.getcwd()
        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise RuntimeError(
                    f'{_("Cannot overwrite file")}: '
                    f'"{norm_path(self.filePath)}".'
                )
            else:
                backedUp = True
        try:
            with zipfile.ZipFile(self.filePath, 'w') as epubTarget:
                os.chdir(self._tempDir)
                for file in self._epubComponents:
                    epubTarget.write(file, compress_type=zipfile.ZIP_DEFLATED)
        except:
            os.chdir(workdir)
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise RuntimeError(
                f'{_("Cannot create file")}: '
                f'"{norm_path(self.filePath)}".'
            )

        os.chdir(workdir)
        self._tear_down()
        return f'{_("File written")}: "{norm_path(self.filePath)}".'

    def write_file(self, localPath, content):
        self._epubComponents.append(localPath)
        try:
            with open(
                f'{self._tempDir}/{localPath}',
                'w',
                encoding='utf-8'
            ) as f:
                f.write(content)
        except:
            raise RuntimeError(f'{_("Cannot write file")}: "{self._tempDir}/{localPath}"')

    def _convert_from_novx(self, text, **kwargs):
        append = kwargs.get('append', False)
        firstInChapter = kwargs.get('firstInChapter', False)
        isEpigraph = kwargs.get('isEpigraph', False)
        xml = kwargs.get('xml', False)

        if not text and not isEpigraph:
            return ''

        if xml:
            self._contentParser.feed(
                text,
                append,
                firstInChapter,
                isEpigraph,
            )
            return ''.join(self._contentParser.xhtmlLines)

        lines = text.split('\n')
        if isEpigraph:
            text = '<br />'.join(lines)
        else:
            text = ('</p><p>').join(lines)

        if isEpigraph:
            attr = ' class="epigraph_source"'
        else:
            attr = ''
        return (
            f'<p{attr}>{text}</p>'
        )
        return(text)

    def _escape_string(self, text):
        if text is None:
            return ''

        return sax.saxutils.escape(text)

    def _get_chapterMapping(self, chId):
        return {
            'ID': chId,
            'Title': self._escape_string(self.novel.chapters[chId].title),
            'Stylesheet': self.CSS_NAME,
        }

    def _get_frontmatterMapping(self):
        return {
            'Title': self._escape_string(self.novel.title),
            'Author': self._escape_string(self.novel.authorName),
            'Stylesheet': self.CSS_NAME,
        }

    def _get_sectionMapping(
            self,
            scId,
            firstInChapter=False,
            isEpigraph=False,
        ):
        return {
            'SectionContent':self._convert_from_novx(
                self.novel.sections[scId].sectionContent,
                append=self.novel.sections[scId].appendToPrev,
                firstInChapter=firstInChapter,
                isEpigraph=isEpigraph,
                xml=True,
            ),
            'Desc':self._convert_from_novx(
                self.novel.sections[scId].desc,
                isEpigraph=isEpigraph,
                append=self.novel.sections[scId].appendToPrev,
            ),
        }

    def _get_sections(
            self,
            chId,
            isEpigraph,
    ):
        lines = []
        firstSectionInChapter = True
        for scId in self.novel.tree.get_children(chId):
            template = None
            sectionContent = self.novel.sections[scId].sectionContent
            if sectionContent is None:
                sectionContent = ''

            if self.novel.sections[scId].scType > 1:
                continue

            elif (
                self.novel.sections[scId].scType == 1
                or self.novel.chapters[chId].chType == 1
            ):
                isEpigraph = False
                continue

            else:
                if isEpigraph:
                    template = Template(self._epigraphTemplate)
                else:
                    template = Template(self._sectionTemplate)

            if not (
                isEpigraph
                or firstSectionInChapter
                or self.novel.sections[scId].appendToPrev
            ):
                lines.append(self._sectionDivider)

            tempEpigraph = False
            tempFirstSection = firstSectionInChapter
            if isEpigraph:
                tempEpigraph = True
                tempFirstSection = False
            lines.append(
                template.safe_substitute(
                    self._get_sectionMapping(
                        scId,
                        firstInChapter=tempFirstSection,
                        isEpigraph=tempEpigraph,
                    )
                )
            )
            isEpigraph = False
            if tempFirstSection:
                firstSectionInChapter = False

        return lines

    def _set_up(self):
        try:
            self._tear_down()
            os.makedirs(f'{self._tempDir}/META-INF')
            os.makedirs(f'{self._tempDir}/OEBPS/styles')
            os.makedirs(f'{self._tempDir}/OEBPS/text')
        except:
            raise RuntimeError(
                f'{_("Cannot create directory")}: '
                f'"{norm_path(self._tempDir)}".'
            )

    def _tear_down(self):
        try:
            rmtree(self._tempDir)
        except:
            pass

    def _write_chapters(self):

        def write_file(contentIndex, text, chId):
            contentFileName = f'content{contentIndex:04}.xhtml'
            ChIdsByContentFileNames[contentFileName] = chId
            self.write_file(f'OEBPS/text/{contentFileName}', text)

        contentIndex = 0
        ChIdsByContentFileNames = {}
        contentIds = ['frontmatter']
        contentIds.extend(self.novel.tree.get_children(CH_ROOT))

        for chId in contentIds:
            lines = []
            if not chId in self.novel.chapters:
                mapping = self._get_frontmatterMapping()
                lines.append(
                    Template(self._frontmatter).safe_substitute(
                        mapping
                    )
                )

            elif self.novel.chapters[chId].chType != 0:
                continue

            else:
                if self.novel.chapters[chId].chLevel == 1:
                    template = Template(self._partTemplate)
                else:
                    template = Template(self._chapterTemplate)
                mapping = self._get_chapterMapping(chId)
                lines.append(
                    template.safe_substitute(mapping)
                )

                lines.extend(
                    self._get_sections(
                        chId,
                        self.novel.chapters[chId].hasEpigraph,
                    )
                )
            if not lines:
                continue

            fileHeader = Template(self._fileHeader).safe_substitute(
                mapping
            )
            text = f'{fileHeader}{"".join(lines)}{self._fileFooter}'
            contentIndex += 1
            write_file(contentIndex, text, chId)

        return ChIdsByContentFileNames

    def _write_content_opf(self, ChIdsByContentFileNames):
        opfMapping = {
            'Uuid': self.uuid,
            'Version': self.version,
            'Date': datetime.date.today().isoformat(),
            'Author': self._escape_string(self.novel.authorName),
            'Language': self.novel.languageCode,
            'Title': self._escape_string(self.novel.title),
            'Coverpage': 'text/content0001.xhtml'
        }
        contentOpfLines = [
            Template(self._CONTENT_OPF_HEADER).safe_substitute(opfMapping),
        ]
        contentOpfLines.append('    <manifest>')
        contentOpfLines.append(
            '        <item id="ncx" href="toc.ncx" '
            'media-type="application/x-dtbncx+xml"/>'
        )
        contentOpfLines.append(
            f'        <item id="{self.CSS_NAME}" '
            f'href="styles/{self.CSS_NAME}" media-type="text/css"/>'
        )
        for fileName in ChIdsByContentFileNames:
            contentOpfLines.append(
                f'        <item id="{fileName}" href="text/{fileName}" '
                'media-type="application/xhtml+xml"/>'

            )
        contentOpfLines.append('    </manifest>')
        contentOpfLines.append('    <spine toc="ncx">')
        for fileName in ChIdsByContentFileNames:
            contentOpfLines.append(
                f'       <itemref idref="{fileName}"/>'
            )
        contentOpfLines.append('    </spine>')
        contentOpfLines.append(
            Template(self._CONTENT_OPF_FOOTER).safe_substitute(opfMapping),
        )
        self.write_file(f'OEBPS/content.opf', '\n'.join(contentOpfLines))

    def _write_toc_ncx(self, ChIdsByContentFileNames):
        ncxMapping = {
            'Uuid': self.uuid,
            'Title': self._escape_string(self.novel.title),
        }
        tocNcxLines = [
            Template(self._TOC_NCX_HEADER).safe_substitute(ncxMapping),
        ]
        i = 0
        for ContentFileName in ChIdsByContentFileNames:
            chId = ChIdsByContentFileNames[ContentFileName]
            if not chId in self.novel.chapters:
                continue

            i += 1
            order = str(i)
            navPointMapping = {
                'NavpointID': f'navPoint-{order}',
                'Playorder': order,
                'Title': self._escape_string(self.novel.chapters[chId].title),
                'Filename': ContentFileName,
                'HeadingID': chId,
            }
            tocNcxLines.append(
                Template(self._TOC_NAV_POINT).safe_substitute(navPointMapping),
            )
        tocNcxLines.append(
            Template(self._TOC_NCX_FOOTER).safe_substitute(ncxMapping),
        )
        self.write_file(f'OEBPS/toc.ncx', '\n'.join(tocNcxLines))
from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon


class Plugin(PluginBase):
    VERSION = '0.4.0'
    API_VERSION = '5.53'
    DESCRIPTION = 'EPUB e-book exporter'
    URL = 'https://github.com/peter88213/nv_epub'
    HELP_URL = 'https://peter88213.github.io/nv_epub/help/'

    FEATURE = f"EPUB {_('e-book')}"

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self._icon = self._get_icon('nv_epub.png')


        pos = self._ui.exportMenu.index(_('Options'))
        self._ui.exportMenu.insert_separator(pos)
        label = self.FEATURE
        self._ui.exportMenu.insert_command(
            pos,
            label=label,
            image=self._icon,
            compound='left',
            command=self._export_epub,
        )
        self._ui.exportMenu.disableOnClose.append(label)

        label = _('nv_epub Online help')
        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self.open_help,
        )

    def _export_epub(self):
        if self._mdl.prjFile is None:
            return False

        if self._mdl.prjFile.filePath is None:
            return False

        self._ui.restore_status()
        self._ui.propertiesView.apply_changes()
        if self._mdl.isModified:
            if not self._ui.ask_yes_no(
                message=_('Save changes?'),
                detail=f"{_('There are unsaved changes')}.",
                title=self.FEATURE,
            ):
                self._ui.set_status(f'#{_("Action canceled by user")}.')
                return False

            self._ctrl.save_project()
        path, __ = os.path.splitext(self._mdl.prjFile.filePath)
        EpubPath = f'{path}{Epub.SUFFIX}{Epub.EXTENSION}'
        if os.path.isfile(EpubPath):
            if not self._ui.ask_yes_no(
                message=_('Overwrite existing e-book?'),
                detail=norm_path(EpubPath),
                title=self.FEATURE,
            ):
                self._ui.set_status(f'#{_("Action canceled by user")}.')
                return False

        EpubFile = Epub(EpubPath, version=self.VERSION)
        EpubFile.novel = self._mdl.novel
        try:
            EpubFile.write()
        except Exception as ex:
            self._ui.set_status(f'!{str(ex)}')
            return False

        self._ui.set_status(f'{_("File exported")}: {EpubPath}')
        return True

    def open_help(self):
        webbrowser.open(self.HELP_URL)

